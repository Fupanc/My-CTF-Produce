#/bin/sh

${1}/run.sh