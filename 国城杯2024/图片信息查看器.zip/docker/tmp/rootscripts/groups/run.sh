# /bin/sh

cat /etc/group;