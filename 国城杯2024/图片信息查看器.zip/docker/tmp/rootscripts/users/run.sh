# /bin/sh

cat /etc/passwd;