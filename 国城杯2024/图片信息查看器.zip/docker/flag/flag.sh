#!/bin/sh

echo "$GZCTF_FLAG" > /root/flag
export GZCTF_FLAG=""
